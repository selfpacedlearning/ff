const Option = require('../model/Option');
const path = require('path');


const getTraining = async (req, res) => {

    // console.log(req?.params?.id)
    if (!req?.params?.id) return res.status(400).json({ "message": 'Option ID required' });
    
    // if (!option) {
    //     return res.status(204).json({ 'message': `Option ID ${req.params.id} not found` });
    // }

    if (req.params.id==="1056")
        res.sendFile(path.join(__dirname,'..','views','trainings','1056.html'));
    else
        res.json(req.params.id);

}

module.exports = {
    getTraining
}