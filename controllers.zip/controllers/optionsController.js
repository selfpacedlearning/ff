const Option = require('../model/Option');
const Lasthoq = require('../model/Lasthoq');


// var OptionsZ = ['ضارش','ضهرم', 'ضبتهران', 'ضبرک', 'ضبساما', 'ضهین', 'ضپلا', 'ضترو', 'ضرول', 'ضتفارس', 'ضتوان', 'ضجهش', 'ضحآفرین', 'ضحریل', 'ضخاور', 'ضهمن', 'ضخپارس', 'ضسپا', 'ضستر', 'ضران', 'ضخود', 'ضدار', 'ضدرا', 'ضدی', 'ضذوب', 'ضرویین', 'ضسرو', 'ضسلا', 'ضبدر', 'ضشنا',  'ضتاب', 'ضستا','ضخوز', 'ضفرابورس', 'ضفصبا', 'ضملی', 'ضفلا', 'ضکاریس', 'ضکرمان', 'ضکوثر', 'ضلبخند', 'ضموج', 'ضنطرین', 'ضنوین', 'ضصاد', 'ضملت', 'ضجار', 'ضغدی', 'ضهای', 'ضهم'];

Namads=[];
Namads.push({
  name:'آساس',
  OptionsZ:'ضاساس',
  OptionsT:'طاساس',
  baseIsin:"IRT3SSAF0001",
  navasan:0.225
})
Namads.push({
  name:'ارزش',
  OptionsZ:'ضارش',
  OptionsT:'طارش',
  baseIsin:"IRT1ARZS0001",
  navasan:0.241	
})
Namads.push({
  name:'اهرم',
  OptionsZ:'ضهرم',
  OptionsT:'طهرم',
  baseIsin:"IRT1AHRM0001",
  navasan:0.329	
})
Namads.push({
  name:'بتهران',
  OptionsZ:'ضبتهران',
  OptionsT:'طبتهران',
  baseIsin:"IRO7THRP0001",
  navasan:0.347	
})
Namads.push({
  name:'برکت',
  OptionsZ:'ضبرک',
  OptionsT:'طبرک',
  baseIsin:"IRO1BRKT0001",
  navasan:0.381	
})
Namads.push({
  name:'بساما',
  OptionsZ:'ضبساما',
  OptionsT:'طبساما',
  baseIsin:"IRO3BSMZ0001",
  navasan:0.285	
})
Namads.push({
  name:'بهین رو',
  OptionsZ:'ضهین',
  OptionsT:'طهین',
  baseIsin:"IRT1BHIN0001",
  navasan:0.346	
})
// Namads.push({
//   name:'پالایش',
//   OptionsZ:'ضپلا',
//   OptionsT:'طپلا',
//   baseIsin:"IRT1PLSH0001"
// })
// Namads.push({
//   name:'پتروآگاه',
//   OptionsZ:'ضترو',
//   OptionsT:'طترو',
//   baseIsin:"IRT1AGAH0001"
// })
Namads.push({
  name:'پترول',
  OptionsZ:'ضرول',
  OptionsT:'طرول',
  baseIsin:"IRO1IPTR0001",
  navasan:0.274	
})
// Namads.push({
//   name:'تفارس',
//   OptionsZ:'ضتفارس',
//   OptionsT:'طتفارس',
//   baseIsin:"IRO7PGOP0001"
// })
Namads.push({
  name:'توان',
  OptionsZ:'ضتوان',
  OptionsT:'طتوان',
  baseIsin:"IRT3TVAF0001",
  navasan:0.333	
})
Namads.push({
  name:'جهش',
  OptionsZ:'ضجهش',
  OptionsT:'طجهش',
  baseIsin:"IRT1JHSH0001",
  navasan:0.344	
})
// Namads.push({
//   name:'حآفرین',
//   OptionsZ:'ضحآفرین',
//   OptionsT:'طحآفرین',
//   baseIsin:"IRO3RPAZ0001"
// })
// Namads.push({
//   name:'حریل',
//   OptionsZ:'ضحریل',
//   OptionsT:'طحریل',
//   baseIsin:"IRO3HRLZ0001"
// })
Namads.push({
  name:'خاور',
  OptionsZ:'ضخاور',
  OptionsT:'طخاور',
  baseIsin:"IRO3IKDP0001",
  navasan:0.344	
})
Namads.push({
  name:'خبهمن',
  OptionsZ:'ضهمن',
  OptionsT:'طهمن',
  baseIsin:"IRO1BHMN0001",
  navasan:0.315	
})
Namads.push({
  name:'خپارس',
  OptionsZ:'ضخپارس',
  OptionsT:'طخپارس',
  baseIsin:"IRO7PKOD0001",
  navasan:0.265	
})
Namads.push({
  name:'خساپا',
  OptionsZ:'ضسپا',
  OptionsT:'طسپا',
  baseIsin:"IRO1SIPA0001",
  navasan:0.289	
})
Namads.push({
  name:'خگستر',
  OptionsZ:'ضستر',
  OptionsT:'طستر',
  baseIsin:"IRO1GOST0001",
  navasan:0.373	
})
Namads.push({
  name:'خودران',
  OptionsZ:'ضران',
  OptionsT:'طران',
  baseIsin:"IRT1KHOD0001",
  navasan:0.394	
})
Namads.push({
  name:'خودرو',
  OptionsZ:'ضخود',
  OptionsT:'طخود',
  baseIsin:"IRO1IKCO0001",
  navasan:0.327	
})
// Namads.push({
//   name:'دارا یکم',
//   OptionsZ:'ضدار',
//   OptionsT:'طدار',
//   baseIsin:"IRT3DAAF0001"
// })
Namads.push({
  name:'دریا',
  OptionsZ:'ضدرا',
  OptionsT:'طدرا',
  baseIsin:"IRT1DYAF0001",
  navasan:0.188	
})
Namads.push({
  name:'دی',
  OptionsZ:'ضدی',
  OptionsT:'طدی',
  baseIsin:"IRO7BDYZ0001",
  navasan:0.282	
})
Namads.push({
  name:'ذوب',
  OptionsZ:'ضذوب',
  OptionsT:'طذوب',
  baseIsin:"IRO1ZOBI0001",
  navasan:0.317	
})
Namads.push({
  name:'رویین',
  OptionsZ:'ضرویین',
  OptionsT:'طرویین',
  baseIsin:"IRT3RUNF0001",
  navasan:0.227	
})
Namads.push({
  name:'سرو',
  OptionsZ:'ضسرو',
  OptionsT:'طسرو',
  baseIsin:"IRT1SARV0001",
  navasan:0.193	
})
Namads.push({
  name:'سلام',
  OptionsZ:'ضسلا',
  OptionsT:'طسلا',
  baseIsin:"IRT1FASA0001",
  navasan:0.199	
})
Namads.push({
  name:'شبندر',
  OptionsZ:'ضبدر',
  OptionsT:'طبدر',
  baseIsin:"IRO1PNBA0001",
  navasan:0.328	
})
Namads.push({
  name:'شپنا',
  OptionsZ:'ضشنا',
  OptionsT:'طشنا',
  baseIsin:"IRO1PNES0001",
  navasan:0.351	
})
Namads.push({
  name:'شتاب',
  OptionsZ:'ضتاب',
  OptionsT:'طتاب',
  baseIsin:"IRT1SHTF0001",
  navasan:0.327	
})
Namads.push({
  name:'شستا',
  OptionsZ:'ضستا',
  OptionsT:'طستا',
  baseIsin:"IRO1TAMN0001",
  navasan:0.218	
})
// Namads.push({
//   name:'فاراک',
//   OptionsZ:'ضخوز',
//   OptionsT:'طخوز',
//   baseIsin:"IRO1MARK0001"
// })
Namads.push({
  name:'فخوز',
  OptionsZ:'ضخوز',
  OptionsT:'طخوز',
  baseIsin:"IRO1FKHZ0001",
  navasan:0.202	
})
Namads.push({
  name:'فرابورس',
  OptionsZ:'ضفرابورس',
  OptionsT:'طفرابورس',
  baseIsin:"IRO3FRBZ0001",
  navasan:0.344	
})
Namads.push({
  name:'فصبا',
  OptionsZ:'ضفصبا',
  OptionsT:'طفصبا',
  baseIsin:"IRO3SBLZ0001",
  navasan:0.283	
})
Namads.push({
  name:'فملی',
  OptionsZ:'ضملی',
  OptionsT:'طملی',
  baseIsin:"IRO1MSMI0001",
  navasan:0.252	
})
Namads.push({
  name:'فولاد',
  OptionsZ:'ضفلا',
  OptionsT:'طفلا',
  baseIsin:"IRO1FOLD0001",
  navasan:0.253	
})
Namads.push({
  name:'کاریس',
  OptionsZ:'ضکاریس',
  OptionsT:'طکاریس',
  baseIsin:"IRT3SSKF0001",
  navasan:0.172	
})
Namads.push({
  name:'کرمان',
  OptionsZ:'ضکرمان',
  OptionsT:'طکرمان',
  baseIsin:"IRO3KRMZ0001",
  navasan:0.438	
})
// Namads.push({
//   name:'کوثر',
//   OptionsZ:'ضکوثر',
//   OptionsT:'طکوثر',
//   baseIsin:"IRO3BKSZ0001"
// })
Namads.push({
  name:'لبخند',
  OptionsZ:'ضلبخند',
  OptionsT:'طلبخند',
  baseIsin:"IRT3LABF0001",
  navasan:0.007	
})
Namads.push({
  name:'موج',
  OptionsZ:'ضموج',
  OptionsT:'طموج',
  baseIsin:"IRT3MOJF0001",
  navasan:0.384	
})
// Namads.push({
//   name:'نطرین',
//   OptionsZ:'ضنطرین',
//   OptionsT:'طنطرین',
//   baseIsin:"IRO3ANQZ0001"
// })
// Namads.push({
//   name:'نوین',
//   OptionsZ:'ضنوین',
//   OptionsT:'طنوین',
//   baseIsin:"IRO3BNOP0001"
// })
Namads.push({
  name:'وبصادر',
  OptionsZ:'ضصاد',
  OptionsT:'طصاد',
  baseIsin:"IRO1BSDR0001",
  navasan:0.241	
})
Namads.push({
  name:'وبملت',
  OptionsZ:'ضملت',
  OptionsT:'طملت',
  baseIsin:"IRO1BMLT0001",
  navasan:0.278	
})
Namads.push({
  name:'وتجارت',
  OptionsZ:'ضجار',
  OptionsT:'طجار',
  baseIsin:"IRO1BTEJ0001",
  navasan:0.235	
})
// Namads.push({
//   name:'وساپا',
//   OptionsZ:'ضجار',
//   OptionsT:'طجار',
//   baseIsin:"IRO1SSAP0001"
// })
Namads.push({
  name:'وکغدیر',
  OptionsZ:'ضغدی',
  OptionsT:'طغدی',
  baseIsin:"IRO1TMGD0001",
  navasan:0.163	
})
Namads.push({
  name:'های وب',
  OptionsZ:'ضهای',
  OptionsT:'طهای',
  baseIsin:"IRO1HWEB0001",
  navasan:0.261	
})
Namads.push({
  name:'هم وزن',
  OptionsZ:'ضهم وزن',
  OptionsT:'طهم وزن',
  baseIsin:"IRT3KNIF0001",
  navasan:0.241	
})


// const JDate = require('jalali-date');

const saveData = async (req, res) => {
    const resultFilter = req.body;

    await Option.create(resultFilter);

    for (let i=1; i<resultFilter.length; i++)
        if(resultFilter[i].newHoqSell>0)
            await Lasthoq.create(resultFilter[i]);

    res.json("ok");
}

const searchoption = async (req, res) => {
    const { searchvalue } = req.body;

    var sv = JSON.parse(searchvalue);
    console.log(sv)

    if(sv=='')
        sv="xxx"

    const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1);
    if (!optionsTotal2) return res.status(204).json({ 'message': 'No option found' });
    const optionsTotal=optionsTotal2[0];
    var datetime = optionsTotal.datetime;

    const option = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                emal: { $gt: 0 },
                name: {'$regex': sv}
            }
        },
        { $limit: 10 },
        { $project : { _id:0, name:1, ic : 1, fullName:1} }
    ])
    if (!option) return res.status(204).json({ 'message': 'No option found' });
    res.json(option);
}


const getAllOptions = async (req, res) => {
    const options = await Option.find();
    if (!options) return res.status(204).json({ 'message': 'No option found' });
    res.json(options);
}

const getSortOptions = async (req, res) => {
    const { settings } = req.body;
    const Settings = JSON.parse(settings);

    const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1);
    if (!optionsTotal2) return res.status(204).json({ 'message': 'No option found' });
    const optionsTotal=optionsTotal2[0];
    var datetime = optionsTotal.datetime;
    const date = optionsTotal.date;

    const optionsLasthoq = await Lasthoq.find({date:date}).sort({_id:-1}).limit(20);

    var Parameters = Array.from(Array(10), () => new Array(0));
    var Index = Array.from(Array(10), () => new Array(0));

    var callput = [];
    if (Settings.call==true)
        callput.push(true);
    if (Settings.put==true)
        callput.push(false);
    var groups=Settings.group;
    if (groups[0])
        groups=[...Array(200).keys()];
    var months=Settings.month;
    if (months[0])
        months=[1,2,3,4,5,6,7,8,9,10,11,12];
    var vPlus=-1;
    if (Settings.vPlus)
        vPlus=0;
    var inSood=[false,true];
    if (Settings.inSood)
        inSood=[true];
    var emalDay=Infinity;
    if (Settings.emalDay)
        emalDay=1;
    var minAhrom=0;
    if (Settings.minAhrom!=='')
        minAhrom=Number(Settings.minAhrom);
    var maxAhrom=Infinity;
    if (Settings.maxAhrom!=='')
        maxAhrom=Number(Settings.maxAhrom);
    var minSarDaily=-Infinity;
    if (Settings.minSarDaily!=='')
        minSarDaily=Number(Settings.minSarDaily);
    var maxSarDaily=Infinity;
    if (Settings.maxSarDaily!=='')
        maxSarDaily=Number(Settings.maxSarDaily);
    var minSarTotal=-Infinity;
    if (Settings.minSarTotal!=='')
        minSarTotal=Number(Settings.minSarTotal);
    var maxSarTotal=Infinity;
    if (Settings.maxSarTotal!=='')
        maxSarTotal=Number(Settings.maxSarTotal);
    var baseIsin=[];
    if (Settings.paye[0])
        for (let i=0; i<Namads.length; i++){
            baseIsin[i]=Namads[i].baseIsin;
        }
    else
        for (let i=1; i<Settings.paye.length; i++){
            baseIsin[i-1]=Namads[Settings.paye[i]-1].baseIsin;
        }

    var Filters = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                emal: { $gt: 0 },
                callput: { $in: callput },
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                $or: [
                    {
                        ahromS: {
                            $gte: minAhrom,
                            $lte: maxAhrom 
                        },
                        sarBEsariPercentS: { 
                            $gte: minSarTotal,
                            $lte: maxSarTotal 
                        },
                        sarBEsariDaily: { 
                            $gte: minSarDaily,
                            $lte: maxSarDaily 
                        }
                    },
                    {
                        ahromS: { $type: 10 }
                    },
                    {
                        sarBEsariPercentS: { $type: 10 }
                    },
                    {
                        sarBEsariDaily: { $type: 10 }
                    }
                ]
            }
        },
        { $project : { _id:0 } }
    ])
    // console.log(Filters.length)

    // var vol=[];;
    // var ahromS=[];
    // var Spercent=[];
    // var sarBEsariPercentS=[];
    // var sarBEsariDaily=[];
    // var blackPercent=[];
    // var openPositions=[];
    // var hoqSell=[];
    // var sarBEsariPercentB=[];
    optionName=[];

    for (let i=0; i<Filters.length; i++){
        optionName[i]=Filters[i].name;
        Parameters[0][i]=Filters[i].vol;
        Parameters[1][i]=Filters[i].ahromS;
        Parameters[2][i]=Filters[i].Spercent;
        Parameters[3][i]=Filters[i].sarBEsariPercentS;
        Parameters[4][i]=Filters[i].sarBEsariDaily;
        Parameters[5][i]=Filters[i].blackPercent;
        Parameters[6][i]=Filters[i].openPositions;
        Parameters[7][i]=Filters[i].hoqSell;
        Parameters[8][i]=Filters[i].sarBEsariPercentB;
        Parameters[9][i]=Filters[i].newPosition;
    }

    var sortTypes = Settings.sort;

    if(Settings.dideban){// Classic Dideban

        var index=0;
        for(var i=0; i<10; i++){ 
            if(sortTypes[i]!==0){
                index=i;
                break;
            }
        }
        if(sortTypes[index]==1)
            Index = Array.from(Array(Parameters[index].length).keys()).sort((a, b) => Parameters[index][a] < Parameters[index][b] ? -1 : (Parameters[index][b] < Parameters[index][a]) | 0)
        else
            Index = Array.from(Array(Parameters[index].length).keys()).sort((b, a) => Parameters[index][a] < Parameters[index][b] ? -1 : (Parameters[index][b] < Parameters[index][a]) | 0)

        var selectedOptions=[];
        var name=[];
        var value=Array.from(Array(10), () => new Array(0));
        for(var filter=0; filter<10; filter++){
            for (let i=0; i<Filters.length; i++){
                if(Parameters[filter][Index[i]]!==null){
                    if(filter==0)
                        name.push(optionName[Index[i]]);
                    value[filter].push(Parameters[filter][Index[i]]);

                    selectedOptions.push(Index[i]);
                    if (value[filter].length>=40)
                        break;
                }
            }
        }

        options={
            name: name,
            value: value
        }

    }else{// Pro Dideban

        for (let i=0; i<10; i++)
            if (sortTypes[i]==1)//soudi nozooli
                Index[i] = Array.from(Array(Parameters[i].length).keys()).sort((a, b) => Parameters[i][a] < Parameters[i][b] ? -1 : (Parameters[i][b] < Parameters[i][a]) | 0)
            else
                Index[i] = Array.from(Array(Parameters[i].length).keys()).sort((b, a) => Parameters[i][a] < Parameters[i][b] ? -1 : (Parameters[i][b] < Parameters[i][a]) | 0)

        var options=[];
        var selectedOptions=[];
        for(var filter=0; filter<10; filter++){

            var name=[];
            var value=[];
            var percent=[];
        
            for (let i=0; i<Filters.length; i++){
                if(Parameters[filter][Index[filter][i]]!==null){
                    name.push(optionName[Index[filter][i]]);
                    value.push(Parameters[filter][Index[filter][i]]);
                    if(filter===3)
                        percent.push(Parameters[1][Index[filter][i]])
                    else
                        percent.push(Parameters[3][Index[filter][i]])
                    selectedOptions.push(Index[filter][i]);
                    if (name.length>=20)
                        break;
                }
            }

            options[filter]={
                name: name,
                value: value,
                percent:percent
            }
        }

        name=[];
        value=[];
        percent=[];
        for (let i=0; i<optionsLasthoq.length; i++){
            name[i]=optionsLasthoq[i].name;
            value[i]=optionsLasthoq[i].haqSell;
            percent[i]=optionsLasthoq[i].sarBEsariPercentS;
        }

        options[10]={
            name: name,
            value: value,
            percent:percent
        }
    }

    selectedOptions = selectedOptions.filter((e, i, a) => a.indexOf(e) === i);

    var params = Array.from(Array(58), () => new Array(0));

    selectedOptions.map((value)=>{
        params[0].push(Filters[value].name);
        params[1].push(Filters[value].isin);
        params[2].push(Filters[value].ic);
        params[3].push(Filters[value].hoqBuy);
        params[4].push(Filters[value].haqBuy);
        params[5].push(Filters[value].hoqSell);
        params[6].push(Filters[value].haqSell);
        params[7].push(Filters[value].ppercent);
        params[8].push(Filters[value].pprice);
        params[9].push(Filters[value].lprice);
        params[10].push(Filters[value].lpercent);
        params[11].push(Filters[value].vol);
        params[12].push(Filters[value].openPositions);
        params[13].push(Filters[value].days);
        params[14].push(Filters[value].emal);
        params[15].push(Filters[value].situation);
        params[16].push(Filters[value].firstSell);
        params[17].push(Filters[value].firstBuy);
        params[18].push(Filters[value].orders);
        params[19].push(Filters[value].minPrice);
        params[20].push(Filters[value].maxPrice);
        params[21].push(Filters[value].yesterday);
        params[22].push(Filters[value].contractSize);
        params[23].push(Filters[value].inSood);
        // params[24].push(optionsLasthoq[0]);
        params[25].push(Filters[value].contractSize);
        params[26].push(Filters[value].emal);
        params[27].push(Filters[value].Bpercent);
        params[28].push(Filters[value].Spercent);
        params[29].push(Filters[value].minpercent);
        params[30].push(Filters[value].maxpercent);
        params[31].push(Filters[value].sarBEsariPriceS);
        params[32].push(Filters[value].sarBEsariPriceB);
        params[33].push(Filters[value].sarBEsariPriceL);
        params[34].push(Filters[value].sarBEsariPercentS);
        params[35].push(Filters[value].sarBEsariPercentB);
        params[36].push(Filters[value].sarBEsariPercentL);
        params[37].push(Filters[value].sarBEsariDaily);
        params[38].push(Filters[value].blackPercent);
        params[39].push(Filters[value].ahromS);
        params[40].push(Filters[value].ahromB);
        params[41].push(Filters[value].ahromL);
        params[42].push(Filters[value].base);
        params[43].push(Filters[value].month);
        params[44].push(Filters[value].baseIsin);
        params[45].push(Filters[value].groupId);
        params[46].push(Filters[value].arzesh);
        params[47].push(Filters[value].fullName);
        params[48].push(Filters[value].inSood);
        params[49].push(Filters[value].Delta);
        params[50].push(Filters[value].Theta);
        params[51].push(Filters[value].Rho);
        params[52].push(Filters[value].Gamma);
        params[53].push(Filters[value].Vega);
        params[54].push(Filters[value].Black);
        params[55].push(Filters[value].minpercent);
        params[56].push(Filters[value].maxpercent);
        params[57]=Filters[value].time;
    })

    for (let i=0; i<optionsLasthoq.length; i++){
        params[0].push(optionsLasthoq[i].name);
        params[1].push(optionsLasthoq[i].isin);
        params[2].push(optionsLasthoq[i].ic);
        params[3].push(optionsLasthoq[i].hoqBuy);
        params[4].push(optionsLasthoq[i].haqBuy);
        params[5].push(optionsLasthoq[i].hoqSell);
        params[6].push(optionsLasthoq[i].haqSell);
        params[7].push(optionsLasthoq[i].ppercent);
        params[8].push(optionsLasthoq[i].pprice);
        params[9].push(optionsLasthoq[i].lprice);
        params[10].push(optionsLasthoq[i].lpercent);
        params[11].push(optionsLasthoq[i].vol);
        params[12].push(optionsLasthoq[i].openPositions);
        params[13].push(optionsLasthoq[i].days);
        params[14].push(optionsLasthoq[i].emal);
        params[15].push(optionsLasthoq[i].situation);
        params[16].push(optionsLasthoq[i].firstSell);
        params[17].push(optionsLasthoq[i].firstBuy);
        params[18].push(optionsLasthoq[i].orders);
        params[19].push(optionsLasthoq[i].minPrice);
        params[20].push(optionsLasthoq[i].maxPrice);
        params[21].push(optionsLasthoq[i].yesterday);
        params[22].push(optionsLasthoq[i].contractSize);
        params[23].push(optionsLasthoq[i].inSood);
        // params[24].push(optionsLasthoq[0]);
        params[25].push(optionsLasthoq[i].contractSize);
        params[26].push(optionsLasthoq[i].emal);
        params[27].push(optionsLasthoq[i].Bpercent);
        params[28].push(optionsLasthoq[i].Spercent);
        params[29].push(optionsLasthoq[i].minpercent);
        params[30].push(optionsLasthoq[i].maxpercent);
        params[31].push(optionsLasthoq[i].sarBEsariPriceS);
        params[32].push(optionsLasthoq[i].sarBEsariPriceB);
        params[33].push(optionsLasthoq[i].sarBEsariPriceL);
        params[34].push(optionsLasthoq[i].sarBEsariPercentS);
        params[35].push(optionsLasthoq[i].sarBEsariPercentB);
        params[36].push(optionsLasthoq[i].sarBEsariPercentL);
        params[37].push(optionsLasthoq[i].sarBEsariDaily);
        params[38].push(optionsLasthoq[i].blackPercent);
        params[39].push(optionsLasthoq[i].ahromS);
        params[40].push(optionsLasthoq[i].ahromB);
        params[41].push(optionsLasthoq[i].ahromL);
        params[42].push(optionsLasthoq[i].base);
        params[43].push(optionsLasthoq[i].month);
        params[44].push(optionsLasthoq[i].baseIsin);
        params[45].push(optionsLasthoq[i].groupId);
        params[46].push(optionsLasthoq[i].arzesh);
        params[47].push(optionsLasthoq[i].fullName);
        params[48].push(optionsLasthoq[i].inSood);
        params[49].push(optionsLasthoq[i].Delta);
        params[50].push(optionsLasthoq[i].Theta);
        params[51].push(optionsLasthoq[i].Rho);
        params[52].push(optionsLasthoq[i].Gamma);
        params[53].push(optionsLasthoq[i].Vega);
        params[54].push(optionsLasthoq[i].Black);
        params[55].push(optionsLasthoq[i].minpercent);
        params[56].push(optionsLasthoq[i].maxpercent);
    }

    const summaryVolT = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                emal: { $gt: 0 }
            }
        },
        {
            $group: {
            _id: null,
            sum: { $sum: '$vol' },
            },
        },
        { $project: { _id: 0 } },
    ]);

    const summaryArzeshT = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                emal: { $gt: 0 }
            }
        },
        {
            $group: {
            _id: null,
            sum: { $sum: '$arzesh' },
            },
        },
        { $project: { _id: 0 } },
    ]);

    const summaryVol = await Option.find({datetime:datetime, emal: { $gt: 0 }},{_id:0, vol:1, name:1}).sort({vol:-1}).limit(1);
    const summaryArzesh = await Option.find({datetime:datetime, emal: { $gt: 0 }},{_id:0, arzesh:1, name:1}).sort({arzesh:-1}).limit(1);
    const summaryHoqvol = await Option.find({datetime:datetime, emal: { $gt: 0 }},{_id:0, hoqSell:1, name:1}).sort({hoqSell:-1}).limit(1);
    const summaryPercentP = await Option.find({datetime:datetime, emal: { $gt: 0 }},{_id:0, lpercent:1, name:1}).sort({lpercent:-1}).limit(1);
    const summaryPercentN = await Option.find({datetime:datetime, emal: { $gt: 0 }},{_id:0, lpercent:1, name:1}).sort({lpercent:1}).limit(1);
    const summaryNavasanP = await Option.find({datetime:datetime, emal: { $gt: 0 }},{_id:0, navasanPercent:1, name:1}).sort({navasanPercent:-1}).limit(1);

    // console.log(summaryVolT)
    // console.log(summaryArzeshT)
    // console.log(summaryVol)
    // console.log(summaryArzesh)
    // console.log(summaryHoqvol)
    // console.log(summaryPercentP)
    // console.log(summaryHoqvolN)

    var result = {
        options : options,
        params : params,
        summary : {
            summaryVolT : summaryVolT[0].sum,
            summaryArzeshT : summaryArzeshT[0].sum,
            summaryVol : summaryVol[0],
            summaryArzesh : summaryArzesh[0],
            summaryHoqvol : summaryHoqvol[0],
            summaryPercentP : summaryPercentP[0],
            summaryPercentN : summaryPercentN[0]
        }
    }

    res.json(result);

}


const getSortOptions22 = async (req, res) => {
    const { settings } = req.body;
    const Settings = JSON.parse(settings);

    var Filters = Array.from(Array(12), () => new Array(0));
    var nOptions = 1;

    var groups=Settings.group;
    if (groups[0])
        groups=[...Array(200).keys()];
    var months=Settings.month;
    if (months[0])
        months=[...Array(13).keys()];
    var vPlus=-1;
    if (Settings.vPlus)
        vPlus=0;
    var inSood=[false,true];
    if (Settings.inSood)
        inSood=[true];
    var emalDay=Infinity;
    if (Settings.emalDay)
        emalDay=1;
    var minAhrom=0;
    if (Settings.minAhrom!=='')
        minAhrom=Number(Settings.minAhrom);
    var maxAhrom=Infinity;
    if (Settings.maxAhrom!=='')
        maxAhrom=Number(Settings.maxAhrom);
    var minSarDaily=0;
    if (Settings.minSarDaily!=='')
        minSarDaily=Number(Settings.minSarDaily);
    var maxSarDaily=Infinity;
    if (Settings.maxSarDaily!=='')
        maxSarDaily=Number(Settings.maxSarDaily);
    var minSarTotal=0;
    if (Settings.minSarTotal!=='')
        minSarTotal=Number(Settings.minSarTotal);
    var maxSarTotal=Infinity;
    if (Settings.maxSarTotal!=='')
        maxSarTotal=Number(Settings.maxSarTotal);
    var baseIsin=[Settings.paye[1]];
    if (Settings.paye[0])
        for (let i=0; i<Namads.length; i++){
            baseIsin[i]=Namads[i].baseIsin;
        }
    else
        for (let i=1; i<Settings.paye.length; i++){
            baseIsin[i-1]=Namads[Settings.paye[i]-1].baseIsin;
        }

    Filters[0] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                ahromS: { $type: 10 },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal },
                sarBEsariPercentS: { $type: 10 }
            }
        },
        { $sort: { vol: Settings.sort[0] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, vol : 1, sarBEsariPercentS : 1 } }
    ])

    // Filters[0] = await Option.find({$where: function() {
    //     var a = ss;
    //     return (this.vol !== null && this.emal>0)
    //     // return (this.vol !== null && this.emal>nOptions && ss.group.indexOf(this.group)>-1)
    //  } }, {_id:0, name: 1, sarBEsariPercentS: 1, vol: 1}).sort({vol:sortTypes[0]}).limit(nOptions);

    Filters[1] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal }
            }
        },
        { $sort: { ahromS: Settings.sort[1] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, ahromS : 1, sarBEsariPercentS : 1 } }
    ])

    Filters[2] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal }
            }
        },
        { $sort: { Spercent: Settings.sort[2] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, Spercent : 1, sarBEsariPercentS : 1 } }
    ])

    Filters[3] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal }
            }
        },
        { $sort: { sarBEsariPercentS: Settings.sort[3] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, sarBEsariPercentS : 1, ahromS : 1 } }
    ])

    Filters[4] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal }
            }
        },
        { $sort: { sarBEsariDaily: Settings.sort[4] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, sarBEsariDaily : 1, sarBEsariPercentS : 1 } }
    ])

    Filters[5] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal }
            }
        },
        { $sort: { blackPercent: Settings.sort[5] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, blackPercent : 1, sarBEsariPercentS : 1 } }
    ])

    Filters[6] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                ahromS: { $type: 10 },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal },
                sarBEsariPercentS: { $type: 10 },
            }
        },
        { $sort: { openPositions: Settings.sort[6] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, openPositions : 1, sarBEsariPercentS : 1 } }
    ])

    Filters[7] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                ahromS: { $type: 10 },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal },
                sarBEsariPercentS: { $type: 10 },
            }
        },
        { $sort: { hoqSell: Settings.sort[7] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, hoqSell : 1, sarBEsariPercentS : 1 } }
    ])

    Filters[8] = await Option.aggregate([
        {
            $match: {
                emal: {$exists: true},
                vol: { $gt: vPlus },
                groupId: { $in: groups },
                baseIsin: { $in: baseIsin },
                month: { $in: months },
                inSood: { $in: inSood },
                days: { $lt: emalDay },
                ahromS: { $gte: minAhrom },
                ahromS: { $lte: maxAhrom },
                ahromS: { $type: 10 },
                sarBEsariDaily: { $gte: minSarDaily },
                sarBEsariDaily: { $lte: maxSarDaily },
                sarBEsariDaily: { $type: 10 },
                sarBEsariPercentS: { $gte: minSarTotal },
                sarBEsariPercentS: { $lte: maxSarTotal },
                sarBEsariPercentS: { $type: 10 },
            }
        },
        { $sort: { sarBEsariPercentB: Settings.sort[8] } },
        { $limit: nOptions },
        { $project : { _id:0, name:1, sarBEsariPercentB : 1, sarBEsariPercentS : 1 } }
    ])


    var options=[];
    var name=[];
    var value=[];
    var percent=[];

    for (let f=0; f<9; f++){        
        name=[];
        percent=[];
        value=[];

        for (let i=0; i<Filters[f].length; i++){
            name[i]=Filters[0][i].name;
            percent[i]=Filters[0][i].sarBEsariPercentS;
            if(f==0)
                value[i]=Filters[f][i].vol;
            else if(f==1)
                value[i]=Filters[f][i].ahromS;
            else if(f==2)
                value[i]=Filters[f][i].Spercent;
            else if(f==3)
                value[i]=Filters[f][i].sarBEsariPercentS;
            else if(f==4)
                value[i]=Filters[f][i].sarBEsariDaily;
            else if(f==5)
                value[i]=Filters[f][i].blackPercent;
            else if(f==6)
                value[i]=Filters[f][i].openPositions;
            else if(f==7)
                value[i]=Filters[f][i].hoqSell;
            else if(f==8)
                value[i]=Filters[f][i].sarBEsariPercentB;
        }

        options[f]={
            name: name,
            value: value,
            percent: percent
        }
    }

    var allFilters=[];
    var allIsin=[];
    var allNames=[];
    for (let i=0; i<12; i++){
        for (let j=0; j<Filters[i].length; j++){
            allNames.push(Filters[i][j].name)
        }
    }

    allNames = allNames.filter((e, i, a) => allNames.indexOf(e) === i);

    var selectedOptions = await Option.aggregate([
        {
            $match: {
                name: { $in: allNames }
            }
        }
    ])

    // console.log(selectedOptions)

    var params = Array.from(Array(58), () => new Array(0));
    var chartData="";

    for (let i=0; i<allNames.length; i++){
        params[0].push(selectedOptions[i].name);
        params[1].push(selectedOptions[i].isin);
        params[2].push(selectedOptions[i].ic);
        params[3].push(selectedOptions[i].hoqBuy);
        params[4].push(selectedOptions[i].haqBuy);
        params[5].push(selectedOptions[i].hoqSell);
        params[6].push(selectedOptions[i].haqSell);
        params[7].push(selectedOptions[i].ppercent);
        params[8].push(selectedOptions[i].pprice);
        params[9].push(selectedOptions[i].lprice);
        params[10].push(selectedOptions[i].lpercent);
        params[11].push(selectedOptions[i].vol);
        params[12].push(selectedOptions[i].openPositions);
        params[13].push(selectedOptions[i].days);
        params[14].push(selectedOptions[i].emal);
        params[15].push(selectedOptions[i].situation);
        params[16].push(selectedOptions[i].firstSell);
        params[17].push(selectedOptions[i].firstBuy);
        params[18].push(selectedOptions[i].orders);
        params[19].push(selectedOptions[i].minPrice);
        params[20].push(selectedOptions[i].maxPrice);
        params[21].push(selectedOptions[i].yesterday);
        params[22].push(selectedOptions[i].contractSize);
        params[23].push(selectedOptions[i].inSood);
        // params[24].push(selectedOptions[i].saraneSellV);
        params[25].push(selectedOptions[i].contractSize);
        params[26].push(selectedOptions[i].emal);
        params[27].push(selectedOptions[i].Bpercent);
        params[28].push(selectedOptions[i].Spercent);
        params[29].push(selectedOptions[i].minpercent);
        params[30].push(selectedOptions[i].maxpercent);
        params[31].push(selectedOptions[i].sarBEsariPriceS);
        params[32].push(selectedOptions[i].sarBEsariPriceB);
        params[33].push(selectedOptions[i].sarBEsariPriceL);
        params[34].push(selectedOptions[i].sarBEsariPercentS);
        params[35].push(selectedOptions[i].sarBEsariPercentB);
        params[36].push(selectedOptions[i].sarBEsariPercentL);
        params[37].push(selectedOptions[i].sarBEsariDaily);
        params[38].push(selectedOptions[i].blackPercent);
        params[39].push(selectedOptions[i].ahromS);
        params[40].push(selectedOptions[i].ahromB);
        params[41].push(selectedOptions[i].ahromL);
        params[42].push(selectedOptions[i].base);
        params[43].push(selectedOptions[i].month);
        params[44].push(selectedOptions[i].baseIsin);
        params[45].push(selectedOptions[i].groupId);
        params[46].push(selectedOptions[i].bazar);
        params[47].push(selectedOptions[i].bazar);//fullName
        params[48].push(selectedOptions[i].inSood);
        params[49].push(selectedOptions[i].Delta);
        params[50].push(selectedOptions[i].Theta);
        params[51].push(selectedOptions[i].Rho);
        params[52].push(selectedOptions[i].Gamma);
        params[53].push(selectedOptions[i].Vega);
        params[54].push(selectedOptions[i].Black);
        params[55].push(selectedOptions[i].minpercent);
        params[56].push(selectedOptions[i].maxpercent);
    }
    if(selectedOptions.length)
        params[57]=selectedOptions[0].time;

    var result = {
        options : options,
        chartData : chartData,
        params : params
    }

    res.json(result);

}

const getSortOptions11 = async (req, res) => {
    const { settings } = req.body;
    const Settings = JSON.parse(settings);

    // const jdate = new JDate;
    // const jdate = new JDate.toJalali(new Date("2024,04,24"))
    // console.log(jdate)

    const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1); //.findOne();
    const optionsTotal = optionsTotal2[0];
    if (!optionsTotal) return res.status(204).json({ 'message': 'No option found' });
    
    var Parameters = Array.from(Array(12), () => new Array(0));
    var Index = Array.from(Array(12), () => new Array(0));
    var nFilter = 12;

    Parameters[0]=optionsTotal.sarBEsariPercentS;
    Parameters[1]=optionsTotal.sarBEsariDaily;
    Parameters[2]=optionsTotal.ahromS;
    Parameters[3]=optionsTotal.vol;
    Parameters[4]=optionsTotal.Spercent;
    Parameters[5]=optionsTotal.lpercent;
    Parameters[6]=optionsTotal.hoqSell;
    Parameters[7]=optionsTotal.openPositions;
    Parameters[8]=optionsTotal.days;
    Parameters[9]=optionsTotal.sarBEsariPercentB;
    Parameters[10]=optionsTotal.blackPercent;
    // for (let i=0; i<Parameters[0].length; i++)
    //     if(optionsTotal.hoqSell[i]-optionsTotal2[1].hoqSell[i]>0)
    //         Parameters[11].push(optionsTotal.hoqSell[i])

    optionName=optionsTotal.name;
    var nOption = Parameters[0].length;
    var selectedOptions=[];

    var sortTypes = Settings.sort;

    for (let i=0; i<nFilter-1; i++)
        if (sortTypes[i]==1)//soudi nozooli
            Index[i] = Array.from(Array(Parameters[i].length).keys()).sort((a, b) => Parameters[i][a] < Parameters[i][b] ? -1 : (Parameters[i][b] < Parameters[i][a]) | 0)
        else
            Index[i] = Array.from(Array(Parameters[i].length).keys()).sort((b, a) => Parameters[i][a] < Parameters[i][b] ? -1 : (Parameters[i][b] < Parameters[i][a]) | 0)


    // for (let i=0; i<nFilter; i++){
    //     for (let j=0; j<Parameters[i].length; j++)
    //         Index[i][j]=Math.round(Math.random()*Parameters[i].length);
    // }

    var remainedOptions=[];
    
    for(var i=0; i<nOption; i++){
        if (Settings.group[0]===false){
            var ok=true;
            for(var g=1; g<Settings.group.length; g++){
                if(optionsTotal.groupId[i]===Settings.group[g]){
                    ok=false;
                    break;
                }
            }
            if(ok)
                remainedOptions.push(i);
        }
        if (Settings.paye[0]===false){
            var ok=true;
            for(var o=1; o<Settings.paye.length; o++){
                if(optionName[i].indexOf(OptionsZ[Settings.paye[o]-1])>-1){
                    ok=false;
                    break;
                }
            }
            if(ok)
                remainedOptions.push(i);
        }
        if (Settings.month[0]===false){
            var ok=true;
            for(var m=1; m<Settings.month.length; m++){
                if(Settings.month[m]===optionsTotal.month[i]){
                    ok=false;
                    break;
                }
            }
            if(ok)
                remainedOptions.push(i);
        }
        if (Settings.call===false)        
            if(optionName[i].indexOf("ض")===0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.put===false)        
            if(optionName[i].indexOf("ط")===0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.vPlus)
            if(optionsTotal.vol[i]===0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.inSood)
            if(optionsTotal.inSood[i]===false){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.emalDay)
            if(optionsTotal.days[i]>0){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.minAhrom!=='')
            if(optionsTotal.ahromS[i]<Number(Settings.minAhrom)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.maxAhrom!=='')
            if(optionsTotal.ahromS[i]>Number(Settings.maxAhrom)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.minSarDaily!=='')
            if(optionsTotal.sarBEsariDaily[i]<Number(Settings.minSarDaily)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.maxSarDaily!=='')
            if(optionsTotal.sarBEsariDaily[i]>Number(Settings.maxSarDaily)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.minSarTotal!=='')
            if(optionsTotal.sarBEsariPercentS[i]<Number(Settings.minSarTotal)){
                remainedOptions.push(i);
                continue;
            }
        if (Settings.maxSarTotal!=='')
            if(optionsTotal.sarBEsariPercentS[i]>Number(Settings.maxSarTotal)){
                remainedOptions.push(i);
                continue;
            }
        // if (Settings.minEmal!=='')
        //     if(optionsTotal.emal[i]<Number(Settings.minEmal)){
        //         remainedOptions.push(i);
        //         continue;
        //     }
        // if (Settings.maxEmal!=='')
        //     if(optionsTotal.emal[i]>Number(Settings.maxEmal)){
        //         remainedOptions.push(i);
        //         continue;
        //     }
    }

    console.log(remainedOptions.length)

    // filter output options
    var options=[];
    for(var filter=0; filter<nFilter; filter++){
        var name=[];
        var value=[];
        var percent=[];
        
        // check settings
        for (var s in Settings.minmax){

            // if(Settings.minmax[s].id === String("minF"+(filter+1))){
            //     if (Settings.minmax[s].value === '')
                    var min = -Infinity;
            //     else
            //         var min = Settings.minmax[s].value;
            // }

            // if(Settings.minmax[s].id === String("maxF"+(filter+1))){
            //     if (Settings.minmax[s].value === '')
                    var max = Infinity;
            //     else
            //         var max = Settings.minmax[s].value;
            // }
        }

        for (let i=0; i<nOption; i++){
            let index = Index[filter][i];
            if(remainedOptions.indexOf(index)>-1)
                continue;
            if (Parameters[filter][index] >= min && Parameters[filter][index] <= max && Parameters[filter][index]!==null){
                name.push(optionName[Index[filter][i]]);
                value.push(Parameters[filter][Index[filter][i]]);
                if(filter===0)
                    percent.push(optionsTotal.ahromS[Index[filter][i]])
                else
                    percent.push(Parameters[0][Index[filter][i]])
                selectedOptions.push(Index[filter][i]);
            }
            if (name.length>=10)
                break;
        }

        options[filter]={
            name: name,
            value: value,
            percent:percent
        }
    }
    selectedOptions = selectedOptions.filter((e, i, a) => a.indexOf(e) === i);

    var params = Array.from(Array(58), () => new Array(0));

    selectedOptions.map((value)=>{
        params[0].push(optionsTotal.name[value]);
        params[1].push(optionsTotal.isin[value]);
        params[2].push(optionsTotal.ic[value]);
        params[3].push(optionsTotal.hoqBuy[value]);
        params[4].push(optionsTotal.haqBuy[value]);
        params[5].push(optionsTotal.hoqSell[value]);
        params[6].push(optionsTotal.haqSell[value]);
        params[7].push(optionsTotal.ppercent[value]);
        params[8].push(optionsTotal.pprice[value]);
        params[9].push(optionsTotal.lprice[value]);
        params[10].push(optionsTotal.lpercent[value]);
        params[11].push(optionsTotal.vol[value]);
        params[12].push(optionsTotal.openPositions[value]);
        params[13].push(optionsTotal.days[value]);
        params[14].push(optionsTotal.emal[value]);
        params[15].push(optionsTotal.situation[value]);
        params[16].push(optionsTotal.firstSell[value]);
        params[17].push(optionsTotal.firstBuy[value]);
        params[18].push(optionsTotal.orders[value]);
        params[19].push(optionsTotal.minPrice[value]);
        params[20].push(optionsTotal.maxPrice[value]);
        params[21].push(optionsTotal.yesterday[value]);
        params[22].push(optionsTotal.contractSize[value]);
        params[23].push(optionsTotal.inSood[value]);
        // params[24].push(optionsTotal.saraneSellV[value]);
        params[25].push(optionsTotal.contractSize[value]);
        params[26].push(optionsTotal.emal[value]);
        params[27].push(optionsTotal.Bpercent[value]);
        params[28].push(optionsTotal.Spercent[value]);
        params[29].push(optionsTotal.minpercent[value]);
        params[30].push(optionsTotal.maxpercent[value]);
        params[31].push(optionsTotal.sarBEsariPriceS[value]);
        params[32].push(optionsTotal.sarBEsariPriceB[value]);
        params[33].push(optionsTotal.sarBEsariPriceL[value]);
        params[34].push(optionsTotal.sarBEsariPercentS[value]);
        params[35].push(optionsTotal.sarBEsariPercentB[value]);
        params[36].push(optionsTotal.sarBEsariPercentL[value]);
        params[37].push(optionsTotal.sarBEsariDaily[value]);
        params[38].push(optionsTotal.blackPercent[value]);
        params[39].push(optionsTotal.ahromS[value]);
        params[40].push(optionsTotal.ahromB[value]);
        params[41].push(optionsTotal.ahromL[value]);
        params[42].push(optionsTotal.base[value]);
        params[43].push(optionsTotal.month[value]);
        params[44].push(optionsTotal.baseIsin[value]);
        params[45].push(optionsTotal.groupId[value]);
        params[46].push(optionsTotal.bazar[value]);
        params[47].push(optionsTotal.bazar[value]);//fullName
        params[48].push(optionsTotal.inSood[value]);
        params[49].push(optionsTotal.Delta[value]);
        params[50].push(optionsTotal.Theta[value]);
        params[51].push(optionsTotal.Rho[value]);
        params[52].push(optionsTotal.Gamma[value]);
        params[53].push(optionsTotal.Vega[value]);
        params[54].push(optionsTotal.Black[value]);
        params[55].push(optionsTotal.minpercent[value]);
        params[56].push(optionsTotal.maxpercent[value]);
    })
    params[57]=optionsTotal.time;

    // console.log(params)

    var chartData= [];
    for (let i=0; i<10; i++){
        if (options[2].value[i]<50)
            var y = 200;
        else
            var y = options[2].value[i]
        chartData[i] = {
          x: options[2].name[i],
          y: y
        }
        if (Math.round(Math.random()))
            chartData[i].fillColor = "#38c95f"
        else
            chartData[i].fillColor = "#e83535"
    }

    var result = {
        options : options,
        chartData : chartData,
        params : params
    }

    res.json(result);
}

// const deleteUser = async (req, res) => {
//     if (!req?.body?.id) return res.status(400).json({ "message": 'User ID required' });
//     const user = await User.findOne({ _id: req.body.id }).exec();
//     if (!user) {
//         return res.status(204).json({ 'message': `User ID ${req.body.id} not found` });
//     }
//     const result = await user.deleteOne({ _id: req.body.id });
//     res.json(result);
// }

const getOption = async (req, res) => {
    // console.log(req?.params?.id)
    if (!req?.params?.id) return res.status(400).json({ "message": 'Option ID required' });
    const option = await Option.findOne({ ic: req.params.id });
    if (!option) {
        return res.status(204).json({ 'message': `Option ID ${req.params.id} not found` });
    }
    
    res.render('options', {
        data: req.params.id
    })
}

const getOption2 = async (req, res) => {

    // console.log(req?.params?.id)
    if (!req?.params?.id) return res.status(400).json({ "message": 'Option ID required' });
    
    // if (!option) {
    //     return res.status(204).json({ 'message': `Option ID ${req.params.id} not found` });
    // }
    const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1);
    if (!optionsTotal2) return res.status(204).json({ 'message': 'No option found' });
    const optionsTotal=optionsTotal2[0];
    const date = optionsTotal.date;
    const datetime = optionsTotal.datetime;

    const option = await Option.findOne({ ic: req.params.id, datetime: datetime }).exec();

    const optionsZ = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                emal: { $gt: 0 },
                vol: { $gt: 100 },
                callput: true,
                groupId: option.groupId
            }
        },
        { $sort: { vol: -1 } },
        { $limit: 15 },
        { $project : { _id:0, name:1, vol:1, lpercent:1, arzesh:1 } }
    ])
    const optionsT = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                emal: { $gt: 0 },
                vol: { $gt: 100 },
                callput: false,
                groupId: option.groupId
            }
        },
        { $sort: { vol: -1 } },
        { $limit: 15 },
        { $project : { _id:0, name:1, vol:1, lpercent:1, arzesh:1 } }
    ])
    const optionsP = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                groupId: option.groupId,
                baseIsin: []
            }
        },
        { $sort: { vol: -1 } },
        { $limit: 15 },
        { $project : { _id:0, name:1, vol:1, lpercent:1, arzesh:1 } }
    ])
    const similarOptions = await Option.aggregate([
        {
            $match: {
                datetime: datetime,
                baseIsin: option.baseIsin,
                // callput: option.callput,
                month: option.month
            }
        },
        { $sort: { emal: 1 } },
        { $project : { _id:0, name:1, vol:1, lprice:1, lpercent:1, arzesh:1, emal:1, openPositions:1, ic:1, ahromS:1, callput:1 } }
    ])
    const base = await Option.findOne({ isin: option.baseIsin, datetime:datetime })
    // const baseTotal = await Option.find({ isin: option.baseIsin, date:date })
    // const baseTotal = await Option.aggregate([
    //     {
    //         $match: {
    //             date: date,
    //             isin: option.baseIsin
    //         }
    //     },
    //     { $sort: { datetime: 1 } },
    //     { $project : { _id:0, lprice:1 } }
    // ])

    var basePrice=[];
    // for (var i = 0; i < baseTotal.length; i++) {
    //     if (i % 50 === 0 ) {
    //         basePrice.push(baseTotal[i].lprice);
    //     }
    // }

    
    // const optionsTotal2 = await Option.find().sort({_id:-1}).limit(1);
    // const optionsTotal = optionsTotal2[0];
    // if (!optionsTotal) return res.status(204).json({ 'message': 'No option found' });
    // var ic = optionsTotal.ic;
    // var index = ic.indexOf(req.params.id);
    
    var params = [];

    params[0]=option.name;
    params[1]=option.isin;
    params[2]=option.ic;
    params[3]=option.hoqBuy;
    params[4]=option.haqBuy;
    params[5]=option.hoqSell;
    params[6]=option.haqSell;
    params[7]=option.ppercent;
    params[8]=option.pprice;
    params[9]=option.lprice;
    params[10]=option.lpercent;
    params[11]=option.vol;
    params[12]=option.openPositions;
    params[13]=option.days;
    params[14]=option.emal;
    params[15]=option.situation;
    params[16]=option.firstSell;
    params[17]=option.firstBuy;
    params[18]=option.orders;
    params[19]=option.minPrice;
    params[20]=option.maxPrice;
    params[21]=option.yesterday;
    params[22]=option.contractSize;
    params[23]=option.inSood;
    // params[24]=option.saraneSellV;
    params[25]=option.contractSize;
    params[26]=option.emal;
    params[27]=option.Bpercent;
    params[28]=option.Spercent;
    params[29]=option.minpercent;
    params[30]=option.maxpercent;
    params[31]=option.sarBEsariPriceS;
    params[32]=option.sarBEsariPriceB;
    params[33]=option.sarBEsariPriceL;
    params[34]=option.sarBEsariPercentS;
    params[35]=option.sarBEsariPercentB;
    params[36]=option.sarBEsariPercentL;
    params[37]=option.sarBEsariDaily;
    params[38]=option.blackPercent;
    params[39]=option.ahromS;
    params[40]=option.ahromB;
    params[41]=option.ahromL;
    params[42]=option.base;
    params[43]=option.month;
    params[44]=option.baseIsin;
    params[45]=option.groupId;
    params[46]=option.arzesh;
    params[47]=option.fullName;
    params[48]=option.inSood;
    params[49]=option.Delta;
    params[50]=option.Theta;
    params[51]=option.Rho;
    params[52]=option.Gamma;
    params[53]=option.Vega;
    params[54]=option.Black;
    params[55]=option.minpercent;
    params[56]=option.maxpercent;
    params[57]=option.time;

    var chartDataZ= [];
    for (let i=0; i<optionsZ.length; i++){
        if (optionsZ[i].vol<50)
            var y = 10;
        else
            var y = optionsZ[i].vol;
        chartDataZ[i] = {
          x: optionsZ[i].name,
          y: y,
          z:{
            p:optionsZ[i].lpercent,
            a:optionsZ[i].arzesh
          }
        }
        if (optionsZ[i].lpercent>=0)
            chartDataZ[i].fillColor = "#38c95f"
        else
            chartDataZ[i].fillColor = "#e83535"
    }

    var chartDataT= [];
    for (let i=0; i<optionsT.length; i++){
        if (optionsT[i].vol<10)
            var y = 10;
        else
            var y = optionsT[i].vol;
        chartDataT[i] = {
          x: optionsT[i].name,
          y: y,
          z:{
            p:optionsT[i].lpercent,
            a:optionsT[i].arzesh
          }
        }
        if (optionsT[i].lpercent>=0)
            chartDataT[i].fillColor = "#38c95f"
        else
            chartDataT[i].fillColor = "#e83535"
    }

    var chartDataP= [];
    for (let i=0; i<optionsP.length; i++){
        if (optionsP[i].vol<10)
            var y = 10;
        else
            var y = optionsP[i].vol;
            chartDataP[i] = {
          x: optionsP[i].name,
          y: y,
          z:{
            p:optionsP[i].lpercent,
            a:optionsP[i].arzesh
          }
        }
        if (optionsP[i].lpercent>=0)
            chartDataP[i].fillColor = "#38c95f"
        else
            chartDataP[i].fillColor = "#e83535"
    }

    var result = {
        params : params,
        base:{
            orders: base.orders,
            vol: base.vol,
            arzesh: base.arzesh,
            ppercent: base.ppercent,
            pprice: base.pprice,
            lpercent: base.lpercent,
            lprice: base.lprice,
            name: base.name
        },
        chartDataZ : chartDataZ,
        chartDataT : chartDataT,
        chartDataP : chartDataP,
        similarOptions : similarOptions
    }

    res.json(result);

}

module.exports = {
    getAllOptions,
    getSortOptions,
    getOption,
    getOption2,
    saveData,
    searchoption
}