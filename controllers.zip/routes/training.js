const express = require('express');
const router = express.Router();
const optionsController = require('../controllers/optionsController');
const trainingController = require('../controllers/trainingController');
// const ROLES_LIST = require('../../config/roles_list');
// const verifyRoles = require('../../middleware/verifyRoles');

// router.route('/')
//     .get(optionsController.getOption);

router.get('/', (req, res) => {

    res.render('training')

});


router.route('/:id/:persian?')
    .get(trainingController.getTraining);

module.exports = router;